package com.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OauthSecurity {

	private static Logger logger = LoggerFactory.getLogger(OauthSecurity.class);

	@GetMapping(value = "/getMsg")
	public String getMSg() {
		logger.info("In GetMsg Method");
		return "NewFile";
	}

	@GetMapping(value = "/getName")
	public String randomName() {
		logger.info("In GetName Method");
		return "rajesh";
	}

}
