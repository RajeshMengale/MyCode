package com.hcl.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.Builder;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;



@RestController
public class ControllerCircute {
	
	private static final String Url="http://localhost:9091/getCustBy/{id}";
	@HystrixCommand(fallbackMethod = "m1")
	@GetMapping("/getCust")
	public String getCustById() {
		
		
		Builder builder = WebClient.builder();
		WebClient webClient = builder.build();
		String block = webClient.get()
				 .uri(Url,2)
				 .retrieve()
				 .bodyToMono(String.class)
				 .block();

		return block;
	}
	
	public String m1() {
		
		return "fallback";
		
	}
	
	

}

