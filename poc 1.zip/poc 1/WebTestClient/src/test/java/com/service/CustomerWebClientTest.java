package com.service;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;


@RunWith(SpringRunner.class)
@WebFluxTest(CustomerWebClientTest.class)
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class CustomerWebClientTest {

	private static final String Get_By_Id = "/getCustBy/1";

	@Autowired
	WebTestClient testClient;

	@Test
	public void CustByIdTest() {
		
		
		/*
		 * CustomerModel consume = testClient.get().uri(Get_By_Id)
		 * .accept(MediaType.APPLICATION_XML) .exchange()
		 * .expectStatus().isEqualTo(HttpStatus.OK) .expectBody(CustomerModel.class)
		 * .consumeWith(cust ->
		 * Assertions.assertThat(cust.getResponseBody()).isNotNull());
		 */
		
		
			WebTestClient testClient = WebTestClient
				.bindToServer()
				.baseUrl("http://localhost:9091")
				.build();
				
		
				//this is ment for given mock response to the webclient (mocking the response)
				RouterFunction function = RouterFunctions.route(
																	RequestPredicates.GET(Get_By_Id),
																	request -> ServerResponse.ok().build()
		);
				
				WebTestClient
				.bindToRouterFunction(function)
				.build().get().uri(Get_By_Id)
				.exchange()
				.expectStatus().isOk()
				.expectBody().isEmpty();

	}

}
