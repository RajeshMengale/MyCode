package com.service;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.Builder;

import com.bindingClass.CustomerModel;

@Service
public class CustomerTest {
	
	
	private static final String Get_By_Id = "http://localhost:9091/getCustBy/7";
	
	
	public void getCustById() {
		Builder builder = WebClient.builder();
		WebClient webClient = builder.build();
		
		 webClient.get()
				 .uri(Get_By_Id)
				 .retrieve()
				 .bodyToFlux(CustomerModel.class)
				 .subscribe(System.out::println);
	} 

}
