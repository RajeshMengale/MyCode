package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.service.CustomerTest;

@SpringBootApplication
public class WebTestClientApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(WebTestClientApplication.class, args);
		CustomerTest bean = ctx.getBean(CustomerTest.class);
		bean.getCustById();

	}

}
