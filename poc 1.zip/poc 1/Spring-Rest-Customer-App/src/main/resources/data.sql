insert into CUSTOMER (CUST_ID,CUST_ADD,CUST_AGE,CUST_NAME) values
(8,'pune',25,'rajesh'),
(9,'pune',26,'sagar'),
(10,'pune',30,'abhinandan');