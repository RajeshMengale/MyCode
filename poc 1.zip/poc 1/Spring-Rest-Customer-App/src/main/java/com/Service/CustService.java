package com.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.CustRepository.CustRepository;
import com.Entity.CostumerEntity;
import com.model.CustomerModel;

@Service
public class CustService {

	@Autowired
	CustRepository repository;

	public ResponseEntity SaveCustomer(CustomerModel c) {

		CostumerEntity entity = new CostumerEntity();

		BeanUtils.copyProperties(c, entity);

		CostumerEntity saveEntity = repository.save(entity);
		if (saveEntity != null) {
			return new ResponseEntity(saveEntity, HttpStatus.OK); 
		}

		return new ResponseEntity(HttpStatus.BAD_REQUEST);
	}

	public CustomerModel getCustById(Integer id) {
		Optional<CostumerEntity> optional = repository.findById(id);
		

		CustomerModel model = new CustomerModel();

		if (optional.isPresent()) {

			CostumerEntity costumerEntity = optional.get();
			
			BeanUtils.copyProperties(costumerEntity, model);

			return model;
		}
		return null;
	}

	public List<CustomerModel> GetByCity(String city) {

		List<CostumerEntity> allByCity = repository.getCustomerBycustAdd(city);
		List<CustomerModel> customerModel = new ArrayList<CustomerModel>();

		if (allByCity != null) {

			allByCity.forEach(cust -> {

				CustomerModel model = new CustomerModel();

				BeanUtils.copyProperties(cust, model);

				customerModel.add(model);

			});
			return customerModel;
		}
		else {
			return null;
		}
		
		

	}

	public CustomerModel getByName(String name) {

		CostumerEntity custByName = repository.getCustByName(name);

		CustomerModel model = new CustomerModel();

		BeanUtils.copyProperties(custByName, model);

		return model;

	}

}
