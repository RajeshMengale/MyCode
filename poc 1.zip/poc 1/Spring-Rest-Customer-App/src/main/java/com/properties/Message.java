package com.properties;

import javax.validation.constraints.Pattern;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import lombok.Data;

@ConfigurationProperties(prefix = "msg")
@Data
@Validated
public class Message {
	/**
	 *  Simple Message 
	 */
	@Pattern(regexp = "\\w+:\\n+")
	private String name;
	/** give your last name */
	private String lastname;

}
