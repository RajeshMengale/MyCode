package com.CustRepository;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Entity.CostumerEntity;
@Repository
public interface CustRepository extends JpaRepository<CostumerEntity, Integer> {

	@Transactional
	//@Query(value = "select * from Customer where CUST_ADD=:city",nativeQuery = true)
	List<CostumerEntity> getCustomerBycustAdd(String city);

	
	@Transactional 
	@Query(value = "select * from customer where CUST_NAME=:name",nativeQuery = true)
	CostumerEntity getCustByName(String name);
	
}
