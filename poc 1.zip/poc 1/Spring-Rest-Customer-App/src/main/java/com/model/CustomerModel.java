package com.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
@Data
public class CustomerModel {

	private Integer custId;

	private String custName;

	private String custAdd;

	private String custAge;

	public Integer getCustId() {
		return custId;
	}

	public String getCustName() {
		return custName;
	}

	public String getCustAdd() {
		return custAdd;
	}

	public String getCustAge() {
		return custAge;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public void setCustAdd(String custAdd) {
		this.custAdd = custAdd;
	}

	public void setCustAge(String custAge) {
		this.custAge = custAge;
	}

	@Override
	public String toString() {
		return "CustomerModel [custId=" + custId + ", custName=" + custName + ", custAdd=" + custAdd + ", custAge="
				+ custAge + "]";
	}

}
