
package com.CustController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.CostumerEntity;
import com.Service.CustService;
import com.model.CustomerModel;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CustomerController {

	@Autowired
	CustService service;

	
	@ApiResponses({ @ApiResponse(code = 200, message = "success"), @ApiResponse(code = 201, message = "created"),
			@ApiResponse(code = 500, message = "bad Request") })
	@PostMapping(value = "/SaveCust", consumes = { "application/json", "application/xml" })
	public String saveCustomer(@RequestBody CustomerModel cust) {

		ResponseEntity<CostumerEntity> saveCustomer = service.SaveCustomer(cust);

		int statusCode = saveCustomer.getStatusCodeValue();

		if (statusCode == 200) {
			return "succses";
		}
		return "fail or duplicate";

	}

	@GetMapping(value = "/getCustBy/{id}")
	public ResponseEntity<CustomerModel> getCustDataById(@PathVariable("id") Integer id) {
		CustomerModel modelObj = service.getCustById(id);

		return new ResponseEntity<CustomerModel>(modelObj, HttpStatus.OK);
	}

	@GetMapping(value = "/city/{city}", produces = { "application/json", "application/xml" })
	public @ResponseBody ResponseEntity<List<CustomerModel>> getAllWithPune(@PathVariable("city") String city) {

		List<CustomerModel> getByCity = service.GetByCity(city);

		return new ResponseEntity<List<CustomerModel>>(getByCity, HttpStatus.OK);

	}

	@GetMapping(value = "/name/{name}", produces = { "application/json", "application/xml" })
	public @ResponseBody CustomerModel getByName(@PathVariable("name") String name) {

		CustomerModel model = service.getByName(name);

		return model;
	}

}
