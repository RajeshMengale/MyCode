package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.properties.Message;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableConfigurationProperties(Message.class)
@EnableSwagger2
public class SpringRestCustomerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestCustomerAppApplication.class, args);
	}

}
