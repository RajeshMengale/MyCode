package com.CustController;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.CustController.CustomerController;
import com.Entity.CostumerEntity;
import com.Service.CustService;
import com.model.CustomerModel;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = CustomerController.class)
public class ControllerTest {

	@Autowired
	MockMvc mockMvc;

	@MockBean
	CustService service;

	public void saveCustomerTestPositive() throws Exception {

		CustomerModel model = new CustomerModel(); 
		model.setCustAdd("pune");
		model.setCustAge("24");

		when(service.SaveCustomer(model)).thenReturn(new ResponseEntity<CostumerEntity>(HttpStatus.OK));

		RequestBuilder builder = MockMvcRequestBuilders.post("/SaveCust")
													   .header("modle", model)
													   .contentType(org.springframework.http.MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mockMvc.perform(builder).andReturn();

		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);

	}

}
