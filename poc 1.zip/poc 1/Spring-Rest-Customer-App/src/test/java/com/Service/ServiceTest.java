package com.Service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.boot.test.context.SpringBootTest;

import com.CustRepository.CustRepository;
import com.Entity.CostumerEntity;
import com.Service.CustService;
import com.model.CustomerModel;

@SpringBootTest
public class ServiceTest {
	@Mock
	CustRepository repository;

	@InjectMocks
	CustService service;

	@Test
	public void saveCustInDb() {

		CostumerEntity entity = new CostumerEntity();
		entity = null;
		
		OngoingStubbing<CostumerEntity> thenReturn = when(repository.save(entity)).thenReturn(entity);
		assertNotNull(entity);

	}

	@Test
	public void getCustomerTestPositive() {

		CostumerEntity entity = new CostumerEntity();
		entity.setCustAdd("pune");
		entity.setCustAge("23");
		entity.setCustName("rajesh");

		Optional<CostumerEntity> optional = Optional.of(entity);

		when(repository.findById(1)).thenReturn(optional);

		CustomerModel cust = service.getCustById(1);
		assertNotNull(cust);

	}

	@Test
	public void getCustomerTestNegativ() {

		CostumerEntity entity = new CostumerEntity();
		Optional<CostumerEntity> optional = Optional.of(entity);
		when(repository.findById(1)).thenReturn(null);
		CustomerModel custById = service.getCustById(12);
		assertNull(custById);

	}

	public void GetByCityTestPositive() {

		List<CostumerEntity> listEntity = new ArrayList<CostumerEntity>();
		CostumerEntity entity = new CostumerEntity();
		entity.setCustAdd("pune");
		entity.setCustAge("24");
		entity.setCustId(23);
		entity.setCustName("rajesh");

		listEntity.add(entity);

		when(repository.getCustomerBycustAdd("pune")).thenReturn(listEntity);

		List<CustomerModel> getByCity = service.GetByCity("pune");

		assertNotNull(getByCity);

	}

	@Test
	public void GetByCityTestNeative() {

		List<CostumerEntity> listEntity = new ArrayList<CostumerEntity>();

		when(repository.getCustomerBycustAdd("pune")).thenReturn(null);

		List<CustomerModel> getByCity = service.GetByCity("pune");

		assertNull(getByCity);
	}

}
